Make All Perfect — Homepage Source Files
========================================

Files included:
- src/app/page.tsx — главная страница (композиция секций)
- src/components/sections/ — все секции главной (.tsx + .module.css)
- src/content/home/ — контент для секций
- src/content/services/index.ts — группы услуг
- src/content/cases/index.ts — кейсы
- src/content/reviews/index.ts — отзывы
- src/components/ui/Container/ — компонент контейнера
- src/components/forms/OpenConsultationButton — кнопка консультации
- src/components/modals/PopupProvider — провайдер модалок
- src/hooks/usePhoneMask — маска телефона
- src/app/globals.css — глобальные токены CSS
- src/styles/grid.module.css — сеточные классы

Секции в порядке:
1. HeroSection
2. ServicesSection
3. HomeAdvantagesSection
4. CasesSection
5. HomeReviewsSection
6. HomeIndustriesSection
7. HomeTechnologiesSection
8. HomeAboutSection
9. HomeBlogSection
10. HomeFaqSection
11. FinalCtaSection
